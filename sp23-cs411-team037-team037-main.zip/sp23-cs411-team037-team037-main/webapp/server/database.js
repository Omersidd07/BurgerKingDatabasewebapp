// var mysql = require("mysql");

// var db = mysql.createConnection({

//     host: '34.136.83.189',
//     user: 'root',
//     password: 'bruh',
//     database: 'borgirking',

// });

// module.exports = db;