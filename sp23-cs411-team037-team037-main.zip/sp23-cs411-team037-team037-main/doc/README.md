# PT1 Stage 6 - Final Video (6 minutes and 40 seconds)
Link: https://youtu.be/8KIbSwyUg-s
