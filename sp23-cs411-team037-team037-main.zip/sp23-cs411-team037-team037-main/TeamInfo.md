# The Burger King Lover

## Basic Information

|   Info      |        Description     |
| ----------- | ---------------------- |
| TeamID      |        team037         |
| TeamName    |        team037         |
| Captain     |       Ananya Barman    |
| Captain     |  ananyab3@illinois.edu |
| Member1     |        Jaeyun Jeong    |
| Member1     |   jaeyunj3@illinois.edu|
| Member2     |       Omer Siddiqi     |
| Member2     |  osiddi20@illinois.edu |
| Member3     |         Hehao Wu       |
| Member3     |  hehaowu2@illinois.edu |

## Project Information

|   Info      |        Description     |
| ----------- | ---------------------- |
|  Title      | The Burger King Lover   
| System URL  |      link_to_system    |
| Video Link  |      link_to_video     |

## Project Summary

Fast food is increasingly popular due to the fast-paced life. On the other hand, a healthy diet is also heatedly discussed among individuals. While it seems hard to pursue a healthy diet while eating fast food, we are going to create an application to allow users to eat as healthy as possible.

We choose Burger King to be our fast food dataset because Burger King is one of the biggest fast food companies in the United States and we believe we can get abundant data to analyze and provide convincing output.

All the detailed descriptions are in the project proposal.
